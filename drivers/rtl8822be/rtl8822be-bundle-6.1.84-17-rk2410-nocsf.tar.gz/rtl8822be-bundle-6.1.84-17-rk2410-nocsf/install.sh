#!/usr/bin/env bash
# Install the extracted RTL8822BE driver onto this machine.
# Must run as root, and `uname -r` MUST match the bundle's KVER.
set -euo pipefail
KVER="$(uname -r)"
HERE="$(cd "$(dirname "$0")" && pwd)"

[[ $EUID -eq 0 ]] || { echo "run as root" >&2; exit 1; }
[[ ${HERE} == *"${KVER}"* ]] || {
    echo "WARNING: bundle is not for this kernel (${KVER})." >&2
    echo "         Refusing to install. Re-extract on a ${KVER} box." >&2
    exit 1
}

cp -a "${HERE}/payload/." /
depmod -a "${KVER}"
systemctl enable depmod-rtw8822be.service
modprobe rtw_8822be
rfkill unblock all 2>/dev/null || true

echo
echo "loaded modules:"
lsmod | grep -i rtw || true
echo
echo "WiFi interfaces:"
ip -brief link show 2>/dev/null | grep -E '^wlan|^wl' || echo "  (none yet - check: journalctl -k | grep rtw)"
